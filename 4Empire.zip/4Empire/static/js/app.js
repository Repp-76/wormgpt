const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

const RANKS = ["Warrior", "Elite", "Master", "Grandmaster", "Epic", "Legend", "Mythic", "Honor", "Glory", "Immortal"];
const MODES = [["Solo", "1 pemain"], ["Duo", "2 pemain"], ["Trio", "3 pemain"], ["Party", "5 pemain"]];
const COMPONENTS = ["com.mobile.legends", "Room Engine", "Player Service", "Rank Service", "Match Service", "Lobby Service", "Session Manager"];
const STEPS = [
  ["Initializing...", 6], ["Preparing room environment...", 1], ["Loading player configuration...", 2],
  ["Loading rank configuration...", 3], ["Loading mode configuration...", 4], ["Preparing room...", 1],
  ["Synchronizing data...", 0], ["Generating room environment...", 1], ["Initializing lobby...", 5],
  ["Finalizing...", 6],
];

const state = { id: "", server: "", rank: "", mode: "" };

function show(name) {
  $$(".step").forEach((s) => (s.hidden = s.dataset.step !== name));
  $("#logout").hidden = name === "login";
}

async function post(url, body) {
  const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
  return { ok: res.ok, data: await res.json().catch(() => ({})) };
}

$("#loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("#loginError").textContent = "";
  const { ok, data } = await post("/api/login", { username: $("#username").value, password: $("#password").value });
  if (!ok) {
    $("#loginError").textContent = data.error || "Invalid Credentials";
    return;
  }
  $("#password").value = "";
  show("player");
});

$("#logout").addEventListener("click", async () => {
  await post("/api/logout");
  show("login");
});

$("#playerForm").addEventListener("submit", (e) => {
  e.preventDefault();
  state.id = $("#mlId").value.trim();
  state.server = $("#mlServer").value.trim();
  show("rank");
});

function buildOptions(group, items, key, nextBtn) {
  const box = $(`[data-group="${group}"]`);
  items.forEach((item) => {
    const [label, hint] = Array.isArray(item) ? item : [item];
    const b = document.createElement("button");
    b.type = "button";
    b.className = "opt";
    b.setAttribute("role", "radio");
    b.setAttribute("aria-checked", "false");
    b.innerHTML = hint ? `${label.toUpperCase()}<small>${hint}</small>` : label.toUpperCase();
    b.addEventListener("click", () => {
      box.querySelectorAll(".opt").forEach((o) => o.setAttribute("aria-checked", "false"));
      b.setAttribute("aria-checked", "true");
      state[key] = label;
      $(nextBtn).disabled = false;
    });
    box.appendChild(b);
  });
}
buildOptions("rank", RANKS, "rank", "#rankNext");
buildOptions("mode", MODES, "mode", "#execute");

$("#rankNext").addEventListener("click", () => show("mode"));
$$("[data-back]").forEach((b) => b.addEventListener("click", () => show(b.dataset.back)));

const mmss = (s) => String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(Math.floor(s % 60)).padStart(2, "0");

function generateLobbyCode() {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  let code = "";
  for (let i = 0; i < 4; i++) code += chars.charAt(Math.floor(Math.random() * chars.length));
  return code;
}

let timer = null;
let stopHelix = null;

function startSimulation() {
  const duration = 60 + Math.floor(Math.random() * 121);
  const start = Date.now();
  let stepIdx = -1;
  let lastFiller = 0;
  const seen = new Set();

  $("#log").innerHTML = "";
  $("#components").innerHTML = COMPONENTS.map((c, i) => `<li data-i="${i}">${c} ( Downloading )</li>`).join("");
  $("#overlay").hidden = false;
  stopHelix = runHelix($("#helix"));

  const addLog = (text, t) => {
    const log = $("#log");
    const row = document.createElement("div");
    row.innerHTML = `<time>${mmss(t)}</time>`;
    row.append(text);
    log.appendChild(row);
    log.scrollTop = log.scrollHeight;
  };

  timer = setInterval(() => {
    const t = (Date.now() - start) / 1000;
    const p = Math.min(t / duration, 1);
    $("#barFill").style.width = p * 100 + "%";
    $("#pct").textContent = Math.floor(p * 100) + "%";
    $("#elapsed").textContent = mmss(Math.min(t, duration));
    $("#remain").textContent = mmss(Math.max(duration - t, 0));

    const target = Math.min(Math.floor(p * STEPS.length), STEPS.length - 1);
    while (stepIdx < target) {
      stepIdx++;
      const [msg, comp] = STEPS[stepIdx];
      seen.add(comp);
      $("#current").textContent = msg;
      addLog(msg, t);
      $$("#components li").forEach((li, i) => {
        li.className = i === comp ? "active" : seen.has(i) ? "done" : "";
      });
      lastFiller = t;
    }
    if (t - lastFiller >= 7 && p < 1) {
      lastFiller = t;
      const c = COMPONENTS[Math.floor(Math.random() * COMPONENTS.length)];
      addLog(`${c} ( Downloading ) ok ${20 + Math.floor(Math.random() * 80)}ms`, t);
    }
    if (p >= 1) finishSimulation();
  }, 250);
}

function closeOverlay() {
  clearInterval(timer);
  if (stopHelix) stopHelix();
  $("#overlay").hidden = true;
}

function finishSimulation() {
  closeOverlay();
  $("#rId").textContent = state.id;
  $("#rServer").textContent = state.server;
  $("#rRank").textContent = state.rank.toUpperCase();
  $("#rMode").textContent = state.mode.toUpperCase();
  $("#lobbyCode").textContent = generateLobbyCode();
  setTimeout(() => ($("#modal").hidden = false), 350);
}

$("#execute").addEventListener("click", startSimulation);
$("#cancelSim").addEventListener("click", closeOverlay);
$("#closeModal").addEventListener("click", () => ($("#modal").hidden = true));

function runHelix(canvas) {
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  let w, h, raf, t = 0;
  const resize = () => {
    w = canvas.clientWidth;
    h = canvas.clientHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };
  resize();
  addEventListener("resize", resize);

  const draw = () => {
    t += 0.008;
    ctx.clearRect(0, 0, w, h);
    const amp = Math.min(w * 0.12, 70);
    const cx = w * 0.5;
    const step = 16;
    for (let y = -step; y < h + step; y += step) {
      const a = y * 0.018 + t * 2;
      const x1 = cx + Math.sin(a) * amp;
      const x2 = cx - Math.sin(a) * amp;
      const depth1 = (Math.cos(a) + 1) / 2;
      const depth2 = 1 - depth1;
      if (Math.round(y / step) % 3 === 0) {
        ctx.strokeStyle = "rgba(201,165,106,.14)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x1, y);
        ctx.lineTo(x2, y);
        ctx.stroke();
      }
      [[x1, depth1], [x2, depth2]].forEach(([x, d]) => {
        ctx.fillStyle = `rgba(201,165,106,${0.25 + d * 0.5})`;
        ctx.beginPath();
        ctx.arc(x, y, 1.5 + d * 1.5, 0, Math.PI * 2);
        ctx.fill();
      });
    }
    raf = requestAnimationFrame(draw);
  };
  draw();
  return () => {
    cancelAnimationFrame(raf);
    removeEventListener("resize", resize);
  };
}

fetch("/api/me").then((r) => r.ok && show("player"));

(function ambient() {
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const canvas = $("#ambient");
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  let w, h, nodes = [];
  const resize = () => {
    w = canvas.clientWidth;
    h = canvas.clientHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const count = Math.max(14, Math.min(34, Math.round((w * h) / 28000)));
    nodes = Array.from({ length: count }, () => ({
      x: Math.random() * w, y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.18, vy: (Math.random() - 0.5) * 0.18,
    }));
  };
  resize();
  addEventListener("resize", resize);

  const reach = 150;
  const frame = () => {
    requestAnimationFrame(frame);
    if (!$("#overlay").hidden || document.hidden) return;
    ctx.clearRect(0, 0, w, h);
    for (const n of nodes) {
      n.x += n.vx; n.y += n.vy;
      if (n.x < 0 || n.x > w) n.vx *= -1;
      if (n.y < 0 || n.y > h) n.vy *= -1;
    }
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const d = Math.hypot(nodes[i].x - nodes[j].x, nodes[i].y - nodes[j].y);
        if (d < reach) {
          ctx.strokeStyle = `rgba(201,165,106,${(1 - d / reach) * 0.1})`;
          ctx.beginPath();
          ctx.moveTo(nodes[i].x, nodes[i].y);
          ctx.lineTo(nodes[j].x, nodes[j].y);
          ctx.stroke();
        }
      }
      ctx.fillStyle = "rgba(201,165,106,.35)";
      ctx.beginPath();
      ctx.arc(nodes[i].x, nodes[i].y, 1.4, 0, Math.PI * 2);
      ctx.fill();
    }
  };
  frame();
})();
