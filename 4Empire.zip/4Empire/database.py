import sqlite3
from datetime import datetime, timedelta
from werkzeug.security import check_password_hash, generate_password_hash

DB = "accounts.db"


def _conn():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def init():
    with _conn() as c:
        c.execute(
            """CREATE TABLE IF NOT EXISTS accounts (
                username TEXT PRIMARY KEY COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL,
                expires_at TEXT
            )"""
        )


def create_account(username, password, delta=None):
    now = datetime.now()
    expires = (now + delta).isoformat() if delta else None
    try:
        with _conn() as c:
            c.execute(
                "INSERT INTO accounts VALUES (?, ?, ?, ?)",
                (username, generate_password_hash(password), now.isoformat(), expires),
            )
    except sqlite3.IntegrityError:
        return False
    return True


def get_account(username):
    with _conn() as c:
        return c.execute("SELECT * FROM accounts WHERE username = ?", (username,)).fetchone()


def is_expired(acc):
    return bool(acc["expires_at"]) and datetime.fromisoformat(acc["expires_at"]) <= datetime.now()


def verify(username, password):
    acc = get_account(username)
    if not acc or not check_password_hash(acc["password_hash"], password):
        return "invalid"
    return "expired" if is_expired(acc) else "ok"
