import os
import re
from datetime import datetime, timedelta

from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

import cloudflared
import database

UNITS = {
    "m": ("minit", lambda n: timedelta(minutes=n)),
    "j": ("jam", lambda n: timedelta(hours=n)),
    "h": ("hari", lambda n: timedelta(days=n)),
    "b": ("bulan", lambda n: timedelta(days=30 * n)),
    "t": ("tahun", lambda n: timedelta(days=365 * n)),
}
USAGE = "Format:\n/create username,password\n/create username,password,duration\n\nDuration: 30m, 12j, 80h, 3b, 1t"


def parse_duration(text):
    m = re.fullmatch(r"(\d{1,5})([mjhbt])", text.lower())
    if not m or int(m.group(1)) == 0:
        return None
    n, unit = int(m.group(1)), m.group(2)
    return f"{n} {UNITS[unit][0]}", UNITS[unit][1](n)


def allowed(user_id):
    ids = [i.strip() for i in os.getenv("ADMIN_IDS", "").split(",") if i.strip()]
    return not ids or str(user_id) in ids


async def create(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update.effective_user.id):
        await update.message.reply_text("Anda tiada kebenaran untuk guna command ini.")
        return
    parts = [p.strip() for p in " ".join(context.args).split(",")]
    if len(parts) not in (2, 3) or not all(parts):
        await update.message.reply_text(USAGE)
        return
    username, password = parts[0], parts[1]
    if not re.fullmatch(r"[A-Za-z0-9_]{3,20}", username):
        await update.message.reply_text("Username mesti 3-20 aksara (huruf, nombor, underscore).")
        return
    if not 4 <= len(password) <= 32 or " " in password:
        await update.message.reply_text("Password mesti 4-32 aksara tanpa ruang.")
        return
    label, delta = "Permanent", None
    if len(parts) == 3:
        parsed = parse_duration(parts[2])
        if not parsed:
            await update.message.reply_text("Duration tidak sah.\n\n" + USAGE)
            return
        label, delta = parsed
    if not database.create_account(username, password, delta):
        await update.message.reply_text(f"Username '{username}' sudah wujud.")
        return
    portal = cloudflared.get_url() or "http://localhost:8980"
    await update.message.reply_text(
        "━━━━━━━━━━━━━━━━━━━━\n"
        "◆  A K A U N  S E D I A  ◆\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        f"▸ Username : {username}\n"
        f"▸ Password : {password}\n"
        f"▸ Tempoh   : {label}\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        f"▸ Portal : {portal}\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "4Empire • Repp76",
        disable_web_page_preview=True,
    )


def run():
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        print("[bot] TELEGRAM_BOT_TOKEN kosong dalam .env. Bot tidak dimulakan, web server tetap jalan.")
        return False
    application = Application.builder().token(token).build()
    application.add_handler(CommandHandler("create", create))
    application.run_polling()
    return True
