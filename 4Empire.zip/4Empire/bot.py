import asyncio
import logging
import os
import re
import signal
import traceback
from datetime import datetime, timedelta

from telegram import LinkPreviewOptions, Update
from telegram.error import NetworkError
from telegram.ext import Application, CommandHandler, ContextTypes
from telegram.request import HTTPXRequest

import cloudflared
import database

UNITS = {
    "m": ("minit", lambda n: timedelta(minutes=n)),
    "j": ("jam", lambda n: timedelta(hours=n)),
    "h": ("hari", lambda n: timedelta(days=n)),
    "b": ("bulan", lambda n: timedelta(days=30 * n)),
    "t": ("tahun", lambda n: timedelta(days=365 * n)),
}
USAGE = "Format:\n/create username,password\n/create username,password,duration\n\nDuration: 30m, 12j, 80h, 3b, 1t"


def parse_duration(text):
    m = re.fullmatch(r"(\d{1,5})([mjhbt])", text.lower())
    if not m or int(m.group(1)) == 0:
        return None
    n, unit = int(m.group(1)), m.group(2)
    return f"{n} {UNITS[unit][0]}", UNITS[unit][1](n)


def allowed(user_id):
    ids = [i.strip() for i in os.getenv("ADMIN_IDS", "").split(",") if i.strip()]
    return not ids or str(user_id) in ids


async def reply(update, text, **kwargs):
    for attempt in range(4):
        try:
            return await update.message.reply_text(text, **kwargs)
        except NetworkError:
            if attempt == 3:
                raise
            await asyncio.sleep(1.5 * (attempt + 1))


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await reply(update, "4Empire • Repp76\n\n" + USAGE)


async def on_error(update, context: ContextTypes.DEFAULT_TYPE):
    err = context.error
    if isinstance(err, NetworkError):
        print(f"[bot] ralat rangkaian, mesej tidak dapat dihantar: {err}")
    else:
        traceback.print_exception(err)


async def create(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update.effective_user.id):
        await reply(update, "Anda tiada kebenaran untuk guna command ini.")
        return
    parts = [p.strip() for p in " ".join(context.args).split(",")]
    if len(parts) not in (2, 3) or not all(parts):
        await reply(update, USAGE)
        return
    username, password = parts[0], parts[1]
    if not re.fullmatch(r"[A-Za-z0-9_]{3,20}", username):
        await reply(update, "Username mesti 3-20 aksara (huruf, nombor, underscore).")
        return
    if not 1 <= len(password) <= 32 or " " in password:
        await reply(update, "Password mesti 1-32 aksara tanpa ruang.")
        return
    label, delta = "Permanent", None
    if len(parts) == 3:
        parsed = parse_duration(parts[2])
        if not parsed:
            await reply(update, "Duration tidak sah.\n\n" + USAGE)
            return
        label, delta = parsed
    if not database.create_account(username, password, delta):
        await reply(update, f"Username '{username}' sudah wujud.")
        return
    portal = cloudflared.get_url() or "http://localhost:8980"
    await reply(update, 
        "━━━━━━━━━━━━━━━━━━━━\n"
        "◆  A K A U N  S E D I A  ◆\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        f"▸ Username : {username}\n"
        f"▸ Password : {password}\n"
        f"▸ Tempoh   : {label}\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        f"▸ Portal : {portal}\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "4Empire • Repp76",
        link_preview_options=LinkPreviewOptions(is_disabled=True),
    )


async def run():
    logging.basicConfig(level=logging.WARNING)
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:
            pass

    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        print("[bot] TELEGRAM_BOT_TOKEN kosong dalam .env. Bot tidak dimulakan, web server tetap jalan.")
        await stop.wait()
        return

    application = (
        Application.builder()
        .token(token)
        .request(HTTPXRequest(connection_pool_size=8, connect_timeout=20, read_timeout=20, write_timeout=20, pool_timeout=20))
        .get_updates_request(HTTPXRequest(connection_pool_size=2, connect_timeout=20, read_timeout=30, write_timeout=20, pool_timeout=20))
        .build()
    )
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("create", create))
    application.add_error_handler(on_error)
    async with application:
        await application.start()
        await application.updater.start_polling(bootstrap_retries=-1)
        print("[bot] polling dimulakan.")
        await stop.wait()
        await application.updater.stop()
        await application.stop()
