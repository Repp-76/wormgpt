import re
import shutil
import subprocess
import threading

_url = None
_found = threading.Event()
URL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")


def start(port):
    threading.Thread(target=_run, args=(port,), daemon=True).start()


def _run(port):
    global _url
    if not shutil.which("cloudflared"):
        print("[cloudflared] tidak dijumpai. Pasang cloudflared dan jalankan semula untuk dapat URL awam.")
        return
    try:
        proc = subprocess.Popen(
            ["cloudflared", "tunnel", "--url", f"http://localhost:{port}"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
    except OSError as e:
        print(f"[cloudflared] gagal dimulakan: {e}")
        return
    for line in proc.stdout:
        m = URL_RE.search(line)
        if m and not _url:
            _url = m.group(0)
            _found.set()
            print(f"[cloudflared] portal: {_url}")
    print("[cloudflared] proses tamat.")


def get_url(wait=15):
    _found.wait(wait)
    return _url
