import os
import threading

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request, session

load_dotenv()

import bot
import cloudflared
import database

PORT = 8980
app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY") or os.urandom(24)


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip()
    result = database.verify(username, str(data.get("password", "")))
    if result == "invalid":
        return jsonify(error="Invalid Credentials"), 401
    if result == "expired":
        return jsonify(error="Account Expired"), 403
    session["user"] = database.get_account(username)["username"]
    return jsonify(username=session["user"])


@app.get("/api/me")
def me():
    acc = database.get_account(session.get("user", ""))
    if not acc or database.is_expired(acc):
        session.clear()
        return jsonify(error="unauthorized"), 401
    return jsonify(username=acc["username"])


@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify(ok=True)


if __name__ == "__main__":
    database.init()
    threading.Thread(
        target=lambda: app.run(host="0.0.0.0", port=PORT, debug=False, use_reloader=False),
        daemon=True,
    ).start()
    cloudflared.start(PORT)
    print(f"[web] http://localhost:{PORT}")
    if not bot.run():
        threading.Event().wait()
