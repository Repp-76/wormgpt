"""
main.py — single entrypoint that starts EVERYTHING with one command:

    python main.py

This runs:
  * the main website        -> http://0.0.0.0:8980
  * the admin dashboard      -> http://0.0.0.0:8089   (background thread)
  * the Telegram account bot                           (background thread)

all inside one Termux session, so you don't need three separate terminal
tabs. Prints the banner once, then stays attached to the main website's
server output in this terminal. Press CTRL+C to stop all three.

You can still run app.py / admin.py / telegram_bot.py separately (e.g. to
deploy them on different machines) — main.py is just the convenient
all-in-one option.
"""
import asyncio
import logging
import threading
import time

import config
from utils import print_banner

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("main")


def _run_admin():
    import admin as admin_module
    try:
        admin_module.app.run(
            host=config.ADMIN_HOST, port=config.ADMIN_PORT,
            debug=False, use_reloader=False, threaded=True,
        )
    except Exception:  # noqa: BLE001
        logger.exception("Admin dashboard crashed.")


def _run_telegram_bot():
    if config.TELEGRAM_BOT_TOKEN == "PUT_YOUR_BOT_TOKEN_HERE":
        logger.warning("Telegram bot NOT started — OSINT_TG_TOKEN is not set.")
        return
    if not config.TELEGRAM_ADMIN_IDS:
        logger.warning("Telegram bot NOT started — OSINT_TG_ADMIN_IDS is empty.")
        return
    try:
        # A background thread has no event loop of its own by default.
        # run_polling() internally calls asyncio.get_event_loop(), which
        # raises RuntimeError on non-main threads unless a loop has been
        # explicitly created and set here first.
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        import telegram_bot
        application = telegram_bot.build_application()
        logger.info("Telegram bot polling started (admin ids: %s).", config.TELEGRAM_ADMIN_IDS)
        # stop_signals=None: signal handlers can only be installed on the
        # main thread on Unix, and this runs in a background thread.
        application.run_polling(stop_signals=None)
    except Exception:  # noqa: BLE001
        logger.exception("Telegram bot crashed. Main website & admin dashboard are unaffected.")


def _check_db():
    try:
        import app as app_module
        from models import db, User
        with app_module.app.app_context():
            db.session.execute(db.select(User).limit(1))
        return True
    except Exception:  # noqa: BLE001
        return False


if __name__ == "__main__":
    db_ok = _check_db()
    tg_configured = (
        config.TELEGRAM_BOT_TOKEN != "PUT_YOUR_BOT_TOKEN_HERE"
        and bool(config.TELEGRAM_ADMIN_IDS)
    )
    print_banner(db_connected=db_ok, tg_connected=tg_configured)

    threading.Thread(target=_run_admin, daemon=True, name="admin-dashboard").start()
    threading.Thread(target=_run_telegram_bot, daemon=True, name="telegram-bot").start()

    # Give both background threads a moment to bind their ports / start
    # polling before the (blocking) main website server takes over stdout.
    time.sleep(1.2)

    import app as app_module
    app_module.app.run(
        host=config.MAIN_HOST, port=config.MAIN_PORT,
        debug=False, use_reloader=False, threaded=True,
    )
