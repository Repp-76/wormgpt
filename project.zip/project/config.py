"""
config.py — central configuration for OsintSpectre-AI.

Every other module reads its settings from here so there is exactly one
place to change ports, secrets, and file locations.
"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ── Ports ─────────────────────────────────────────────────────────────
MAIN_HOST = "0.0.0.0"
MAIN_PORT = 8980
ADMIN_HOST = "0.0.0.0"
ADMIN_PORT = 8089

# ── Paths ─────────────────────────────────────────────────────────────
DATABASE_DIR = os.path.join(BASE_DIR, "database")
DATABASE_PATH = os.path.join(DATABASE_DIR, "database.db")
LOG_DIR = os.path.join(BASE_DIR, "logs")
SESSION_DIR = os.path.join(BASE_DIR, "session")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")

for _d in (DATABASE_DIR, LOG_DIR, SESSION_DIR, UPLOAD_DIR):
    os.makedirs(_d, exist_ok=True)

SQLALCHEMY_DATABASE_URI = f"sqlite:///{DATABASE_PATH}"

# ── Secrets ───────────────────────────────────────────────────────────
# Override these via environment variables in production.
SECRET_KEY = os.environ.get("OSINT_SECRET_KEY", "change-this-secret-in-production-3f8a2c")

# Remember-me cookie lifetime. This is what lets a user stay "logged in"
# across server restarts / Cloudflared link changes / browser close-reopen.
# It does NOT survive the user manually clearing all cookies — see README.
REMEMBER_COOKIE_DAYS = 400

# ── Telegram bot ────────────────────────────────────────────────────────
# Get this from @BotFather. Only this bot can create accounts.
TELEGRAM_BOT_TOKEN = os.environ.get("8293625592:AAHSXnU-X2HhXhi45yhC9mCZgksVM1Tr5RE", "8293625592:AAHSXnU-X2HhXhi45yhC9mCZgksVM1Tr5RE")
# Telegram numeric user ID(s) allowed to run /create. Only you should be here.
TELEGRAM_ADMIN_IDS = {
    int(x) for x in os.environ.get("7624612389", "").split(",") if x.strip().isdigit()
}

# ── Admin dashboard login ──────────────────────────────────────────────
# Change these before deploying. Consider moving to env vars / DB-backed
# admin accounts if you need more than one admin.
ADMIN_USERNAME = os.environ.get("OSINT_ADMIN_USER", "admin")
ADMIN_PASSWORD = os.environ.get("OSINT_ADMIN_PASS", "changeme123")

# ── Branding ──────────────────────────────────────────────────────────
BRAND_NAME = "Osint Spectre-AI"
BRAND_AUTHOR = "Repp76"
