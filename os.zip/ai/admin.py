"""
admin.py — Admin Dashboard (http://0.0.0.0:8089)

Same visual theme as the main site. Lets you (the owner):
  * list/search/filter/sort all accounts, see online/offline + device
  * cancel / restore accounts
  * read every user's chat history (for manual moderation — the system
    NEVER auto-deletes an account; you decide)
  * add / edit / delete dynamic Menu tools, live, no restart needed
"""
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, jsonify, session

import config
from models import db, User, ChatLog, MenuItem
from auth import require_admin

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = config.SQLALCHEMY_DATABASE_URI
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SECRET_KEY"] = config.SECRET_KEY

db.init_app(app)

with app.app_context():
    db.create_all()


# ── Admin login (separate from user login) ─────────────────────────────

@app.route("/login", methods=["GET"])
def admin_login():
    if session.get("is_admin"):
        return redirect(url_for("dashboard"))
    return render_template("admin/login.html", error=None)


@app.route("/login", methods=["POST"])
def admin_login_post():
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    if username == config.ADMIN_USERNAME and password == config.ADMIN_PASSWORD:
        session["is_admin"] = True
        return redirect(url_for("dashboard"))
    return render_template("admin/login.html", error="Invalid admin credentials."), 401


@app.route("/logout")
def admin_logout():
    session.clear()
    return redirect(url_for("admin_login"))


# ── Dashboard ────────────────────────────────────────────────────────────

@app.route("/")
@require_admin
def dashboard():
    return render_template("admin/dashboard.html")


# ── Account management API ───────────────────────────────────────────────

@app.route("/api/accounts", methods=["GET"])
@require_admin
def api_accounts():
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "all")  # all | active | cancelled | expired | online
    sort = request.args.get("sort", "created_desc")

    query = User.query
    if q:
        query = query.filter(User.username.ilike(f"%{q}%"))

    users = query.all()

    if status == "active":
        users = [u for u in users if u.is_active_account]
    elif status == "cancelled":
        users = [u for u in users if u.is_cancelled]
    elif status == "expired":
        users = [u for u in users if u.is_expired and not u.is_cancelled]
    elif status == "online":
        users = [u for u in users if u.is_online]

    reverse = sort.endswith("_desc")
    key = sort.replace("_desc", "").replace("_asc", "")
    key_fn = {
        "created": lambda u: u.created_at or datetime.min,
        "username": lambda u: u.username.lower(),
        "expires": lambda u: u.expires_at or datetime.max,
    }.get(key, lambda u: u.created_at or datetime.min)
    users.sort(key=key_fn, reverse=reverse)

    return jsonify({"accounts": [u.to_dict() for u in users]})


@app.route("/api/accounts/<int:user_id>/cancel", methods=["POST"])
@require_admin
def api_cancel_account(user_id):
    user = db.session.get(User, user_id)
    if not user:
        return jsonify({"ok": False, "error": "not_found"}), 404
    user.is_cancelled = True
    db.session.commit()
    return jsonify({"ok": True})


@app.route("/api/accounts/<int:user_id>/restore", methods=["POST"])
@require_admin
def api_restore_account(user_id):
    user = db.session.get(User, user_id)
    if not user:
        return jsonify({"ok": False, "error": "not_found"}), 404
    user.is_cancelled = False
    db.session.commit()
    return jsonify({"ok": True})


@app.route("/api/accounts/<int:user_id>/reset_device", methods=["POST"])
@require_admin
def api_reset_device(user_id):
    """Unlock the account so it can register a new device (e.g. user got a new phone)."""
    user = db.session.get(User, user_id)
    if not user:
        return jsonify({"ok": False, "error": "not_found"}), 404
    user.device_hash = None
    user.device_label = None
    db.session.commit()
    return jsonify({"ok": True})


@app.route("/api/accounts/<int:user_id>", methods=["DELETE"])
@require_admin
def api_delete_account(user_id):
    """Permanently remove the account (and its chat history, via cascade)
    from the database. Unlike /cancel this cannot be undone — a brand new
    account must be created via the Telegram bot afterwards."""
    user = db.session.get(User, user_id)
    if not user:
        return jsonify({"ok": False, "error": "not_found"}), 404
    db.session.delete(user)
    db.session.commit()
    return jsonify({"ok": True})


# ── Chat monitoring ───────────────────────────────────────────────────────

@app.route("/api/accounts/<int:user_id>/chat", methods=["GET"])
@require_admin
def api_user_chat(user_id):
    user = db.session.get(User, user_id)
    if not user:
        return jsonify({"ok": False, "error": "not_found"}), 404
    logs = ChatLog.query.filter_by(user_id=user_id).order_by(ChatLog.created_at.asc()).all()
    return jsonify({
        "username": user.username,
        "messages": [
            {"role": l.role, "content": l.content, "at": l.created_at.strftime("%Y-%m-%d %H:%M:%S")}
            for l in logs
        ],
    })


# ── Menu management API (live — no restart needed) ────────────────────────

@app.route("/api/menu", methods=["GET"])
@require_admin
def api_menu_list():
    items = MenuItem.query.order_by(MenuItem.sort_order.asc(), MenuItem.id.asc()).all()
    return jsonify({"items": [i.to_dict(censor_url=True) for i in items]})


@app.route("/api/menu", methods=["POST"])
@require_admin
def api_menu_add():
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    url_ = (data.get("url") or "").strip()
    description = (data.get("description") or "").strip()

    if not name or not url_:
        return jsonify({"ok": False, "error": "Tool Name and Tool URL are required."}), 400

    item = MenuItem(name=name, url=url_, description=description)
    db.session.add(item)
    db.session.commit()
    return jsonify({"ok": True, "item": item.to_dict(censor_url=True)})


@app.route("/api/menu/<int:item_id>", methods=["PUT"])
@require_admin
def api_menu_edit(item_id):
    item = db.session.get(MenuItem, item_id)
    if not item:
        return jsonify({"ok": False, "error": "not_found"}), 404
    data = request.get_json(silent=True) or {}
    if "name" in data:
        item.name = data["name"].strip()
    if "url" in data:
        item.url = data["url"].strip()
    if "description" in data:
        item.description = data["description"].strip()
    db.session.commit()
    return jsonify({"ok": True, "item": item.to_dict(censor_url=True)})


@app.route("/api/menu/<int:item_id>", methods=["DELETE"])
@require_admin
def api_menu_delete(item_id):
    item = db.session.get(MenuItem, item_id)
    if not item:
        return jsonify({"ok": False, "error": "not_found"}), 404
    db.session.delete(item)
    db.session.commit()
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(host=config.ADMIN_HOST, port=config.ADMIN_PORT, debug=False)
