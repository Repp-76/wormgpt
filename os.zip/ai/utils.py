"""
utils.py — small shared helpers used across the project.
"""
import re
import hashlib
import socket
from datetime import datetime, timedelta

import config

# ══════════════════════════════════════════════════════════════════════
#  EXPIRY DURATION PARSING (Bahasa Melayu suffix format)
#
#   h = Hari   (days)      e.g. 30h  -> 30 days
#   b = Bulan  (months)    e.g. 6b   -> 6 months  (30 days each, calendar-free)
#   j = Jam    (hours)     e.g. 12j  -> 12 hours
#   t = Tahun  (years)     e.g. 2t   -> 2 years    (365 days each)
# ══════════════════════════════════════════════════════════════════════

_DURATION_RE = re.compile(r"^(\d+)(h|b|j|t)$", re.IGNORECASE)

_UNIT_TO_TIMEDELTA = {
    "j": lambda n: timedelta(hours=n),
    "h": lambda n: timedelta(days=n),
    "b": lambda n: timedelta(days=n * 30),
    "t": lambda n: timedelta(days=n * 365),
}

_UNIT_LABEL = {"j": "Jam", "h": "Hari", "b": "Bulan", "t": "Tahun"}


class InvalidDurationFormat(Exception):
    pass


def parse_expiry(duration_str: str | None):
    """
    Parse a Malay-format duration string like '30h', '6b', '12j', '2t'.

    Returns (expires_at: datetime | None, is_permanent: bool).
    Raises InvalidDurationFormat with a clear Malay error message if the
    format is present but malformed.
    """
    if duration_str is None or duration_str.strip() == "":
        # No expiry part supplied at all -> permanent account.
        return None, True

    duration_str = duration_str.strip()
    match = _DURATION_RE.match(duration_str)
    if not match:
        raise InvalidDurationFormat(
            f"Format tempoh tidak sah: '{duration_str}'. "
            f"Guna format: <nombor><unit> — contoh 30h (30 Hari), 6b (6 Bulan), "
            f"12j (12 Jam), 2t (2 Tahun)."
        )

    amount, unit = int(match.group(1)), match.group(2).lower()
    if amount <= 0:
        raise InvalidDurationFormat("Nombor tempoh mesti lebih daripada 0.")

    delta = _UNIT_TO_TIMEDELTA[unit](amount)
    expires_at = datetime.utcnow() + delta
    return expires_at, False


def format_expiry_label(expires_at, is_permanent) -> str:
    if is_permanent or expires_at is None:
        return "PERMANENT"
    return expires_at.strftime("%Y-%m-%d %H:%M UTC")


_tunnel_url = None


def set_tunnel_url(url: str) -> None:
    """Called by main.py once the Cloudflare Quick Tunnel for the main
    (public/AI) website is confirmed up, so get_public_url() below can
    return the real, internet-reachable link instead of a LAN IP guess."""
    global _tunnel_url
    _tunnel_url = url


def get_tunnel_url():
    return _tunnel_url


def get_public_url() -> str:
    """Best-effort reachable URL for the main (public/AI) website — NOT the
    admin dashboard. Prefers the live Cloudflare tunnel URL (set via
    set_tunnel_url() once main.py's tunnel comes up) since that is
    reachable from anywhere. Falls back to resolving the device's real LAN
    IP if no tunnel is running yet — config.MAIN_HOST is normally
    "0.0.0.0", which is a bind address, not something a user can open."""
    if _tunnel_url:
        return _tunnel_url
    host = config.MAIN_HOST
    if host in ("0.0.0.0", "::"):
        try:
            probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            probe.connect(("8.8.8.8", 80))
            host = probe.getsockname()[0]
            probe.close()
        except OSError:
            host = "127.0.0.1"
    return f"http://{host}:{config.MAIN_PORT}"


# ══════════════════════════════════════════════════════════════════════
#  DEVICE FINGERPRINT
#
#  A single device is identified by hashing a combination of signals the
#  browser reports (user agent, platform, screen size, timezone, an
#  optional canvas hash from the client JS). This is inherently a best
#  effort signal — no purely client-side fingerprint is unspoofable — but
#  combined with the username/password check it is a strong, standard
#  approach for "one account, one device" enforcement.
# ══════════════════════════════════════════════════════════════════════

def compute_device_hash(user_agent: str, fp_platform: str, fp_screen: str,
                         fp_timezone: str, fp_canvas: str) -> str:
    """Combine browser-reported signals into one stable per-device hash."""
    payload = "|".join([
        user_agent or "", fp_platform or "", fp_screen or "",
        fp_timezone or "", fp_canvas or "",
    ])
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def device_label_from_request(request) -> str:
    ua = request.headers.get("User-Agent", "unknown")
    return ua[:200]


# ══════════════════════════════════════════════════════════════════════
#  ANSI TERMINAL BANNER
# ══════════════════════════════════════════════════════════════════════

_RESET = "\033[0m"
_BOLD = "\033[1m"

# 256-color gradient (red -> orange -> yellow) reminiscent of the site theme.
_GRADIENT = [196, 202, 208, 214, 220, 226]


def _grad_text(text: str) -> str:
    out = []
    n = len(_GRADIENT)
    for i, ch in enumerate(text):
        color = _GRADIENT[i % n]
        out.append(f"\033[38;5;{color}m{ch}")
    return "".join(out) + _RESET


def print_banner(db_connected: bool, tg_connected: bool):
    title = f"{config.BRAND_NAME} by {config.BRAND_AUTHOR}"
    width = 62
    line = "━" * width

    print()
    print(_grad_text("█" * width))
    print(_BOLD + _grad_text(title.center(width)) + _RESET)
    print(_grad_text("█" * width))
    print(f"\033[38;5;196m{line}{_RESET}")

    def row(label, value, ok=True):
        color = "\033[38;5;46m" if ok else "\033[38;5;196m"
        print(f" {label:<18}: {color}{value}{_RESET}")

    row("Server Status", "ONLINE")
    row("Main Website", f"http://{config.MAIN_HOST}:{config.MAIN_PORT}")
    row("Admin Dashboard", f"http://{config.ADMIN_HOST}:{config.ADMIN_PORT}")
    row("Database", "CONNECTED" if db_connected else "DISCONNECTED", db_connected)
    row("Telegram Bot", "CONNECTED" if tg_connected else "NOT RUNNING", tg_connected)
    row("Login System", "READY")

    print(f"\033[38;5;196m{line}{_RESET}")
    print()
