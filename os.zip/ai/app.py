"""
app.py — Main website (http://0.0.0.0:8980)

Serves the login page first; only after a valid login (checked against
the SQLite-backed User table with device-lock enforcement) does it serve
the original chat UI (templates/index.html), completely unmodified apart
from: (1) UI text translated to English, (2) a Menu button + slide-out
panel reading from the database, (3) quiet chat-logging hooks for admin
moderation. All original CSS/JS/behaviour is untouched.
"""
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, jsonify, session

import config
from models import db, User, ChatLog, MenuItem
from auth import attempt_login, current_user, require_login

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = config.SQLALCHEMY_DATABASE_URI
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SECRET_KEY"] = config.SECRET_KEY
app.config["PERMANENT_SESSION_LIFETIME"] = config.REMEMBER_COOKIE_DAYS * 24 * 3600
app.config["SESSION_COOKIE_SECURE"] = False  # set True once served over HTTPS/Cloudflared TLS
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

db.init_app(app)

with app.app_context():
    db.create_all()


# ── Login / logout ─────────────────────────────────────────────────────

@app.route("/login", methods=["GET"])
def login():
    if current_user():
        return redirect(url_for("index"))
    return render_template("login.html", error=None)


@app.route("/login", methods=["POST"])
def login_post():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    fp = {
        "platform": request.form.get("fp_platform", ""),
        "screen": request.form.get("fp_screen", ""),
        "timezone": request.form.get("fp_timezone", ""),
        "canvas": request.form.get("fp_canvas", ""),
    }
    ip = request.headers.get("X-Forwarded-For", request.remote_addr)

    ok, error, user = attempt_login(username, password, fp, ip)
    if not ok:
        return render_template("login.html", error=error), 401

    return redirect(url_for("index"))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ── Main chat UI ────────────────────────────────────────────────────────

@app.route("/")
@require_login
def index():
    return render_template("index.html", username=session.get("username"))


# ── API: chat logging (silent — never breaks the original chat flow) ───

@app.route("/api/log", methods=["POST"])
@require_login
def api_log():
    data = request.get_json(silent=True) or {}
    role = data.get("role")
    content = data.get("content")
    conv_id = data.get("conversation_id")

    if role not in ("user", "assistant") or not content:
        return jsonify({"ok": False}), 400

    user = current_user()
    entry = ChatLog(user_id=user.id, role=role, content=content[:20000], conversation_id=conv_id)
    db.session.add(entry)
    db.session.commit()
    return jsonify({"ok": True})


# ── API: dynamic menu (right-hand slide-out panel) ──────────────────────

@app.route("/api/menu", methods=["GET"])
@require_login
def api_menu_list():
    items = MenuItem.query.order_by(MenuItem.sort_order.asc(), MenuItem.id.asc()).all()
    return jsonify({"items": [i.to_dict() for i in items]})


# ── Health check (used by admin dashboard "Database: CONNECTED" check) ──

@app.route("/api/health")
def health():
    try:
        db.session.execute(db.select(User).limit(1))
        return jsonify({"ok": True})
    except Exception as e:  # noqa: BLE001
        return jsonify({"ok": False, "error": str(e)}), 500


if __name__ == "__main__":
    from utils import print_banner

    db_ok = True
    try:
        with app.app_context():
            db.session.execute(db.select(User).limit(1))
    except Exception:  # noqa: BLE001
        db_ok = False

    tg_configured = config.TELEGRAM_BOT_TOKEN != "PUT_YOUR_BOT_TOKEN_HERE"
    print_banner(db_connected=db_ok, tg_connected=tg_configured)

    app.run(host=config.MAIN_HOST, port=config.MAIN_PORT, debug=False)
