"""
auth.py — login, device-lock enforcement, and the require_login decorator
used by app.py.

Design notes
------------
* Accounts can NEVER be created here — only telegram_bot.py can create a
  User row. This module only ever reads/updates existing users.
* Device lock: the first time an account logs in successfully, we store a
  device fingerprint hash on the user row. Every subsequent login attempt
  (even with correct username/password) is rejected if the fingerprint
  does not match, with the exact message the spec requires.
* Persistent login: Flask's session cookie is marked permanent with a
  long lifetime (config.REMEMBER_COOKIE_DAYS) and signed with SECRET_KEY,
  so it survives server restarts, Python restarts, and Cloudflared URL
  changes — because none of those affect the user's own browser cookie
  or the server-side database it is checked against. It does NOT survive
  the user manually clearing all site data, because that erases the
  cookie itself; the closest available fallback is that the account
  stays permanently bound to the same device, so logging in again after
  a full wipe succeeds instantly with no new Telegram command needed.
"""
from datetime import datetime
from functools import wraps

from flask import session, redirect, url_for, request, jsonify

from models import db, User
from utils import compute_device_hash, device_label_from_request

DEVICE_MISMATCH_MSG = "This account has already been registered on another device."


def attempt_login(username: str, password: str, fp: dict, ip: str):
    """
    Returns (success: bool, error_message: str | None, user: User | None)
    """
    user = User.query.filter_by(username=username).first()
    if not user or not user.check_password(password):
        return False, "Invalid username or password.", None

    if user.is_cancelled:
        return False, "This account has been cancelled.", None

    if user.is_expired:
        return False, "This account has expired.", None

    incoming_hash = compute_device_hash(
        user_agent=request.headers.get("User-Agent", ""),
        fp_platform=fp.get("platform", ""),
        fp_screen=fp.get("screen", ""),
        fp_timezone=fp.get("timezone", ""),
        fp_canvas=fp.get("canvas", ""),
    )

    if user.device_hash is None:
        # First login ever -> this becomes the permanent device for the account.
        user.device_hash = incoming_hash
        user.device_label = device_label_from_request(request)
    elif user.device_hash != incoming_hash:
        return False, DEVICE_MISMATCH_MSG, None

    user.last_seen = datetime.utcnow()
    user.last_ip = ip
    db.session.commit()

    session.permanent = True
    session["user_id"] = user.id
    session["username"] = user.username
    return True, None, user


def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    user = db.session.get(User, uid)
    if not user or not user.is_active_account:
        return None
    return user


def require_login(view_func):
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user:
            if request.path.startswith("/api/"):
                return jsonify({"error": "not_authenticated"}), 401
            return redirect(url_for("login"))
        user.last_seen = datetime.utcnow()
        db.session.commit()
        return view_func(*args, **kwargs)
    return wrapped


def require_admin(view_func):
    """Used by admin.py — separate, simpler session flag."""
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if not session.get("is_admin"):
            return redirect(url_for("admin_login"))
        return view_func(*args, **kwargs)
    return wrapped
