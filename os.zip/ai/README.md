# Osint Spectre-AI — Backend

Adds a full Python backend to the existing chat UI without touching its
original design, CSS, JS behaviour, or API key handling.

## Project structure

```
project/
├── app.py              # Main website — Flask, port 8980
├── admin.py             # Admin dashboard — Flask, port 8089
├── telegram_bot.py       # ONLY way to create accounts
├── config.py             # All settings live here
├── models.py            # SQLAlchemy models (User, ChatLog, MenuItem)
├── auth.py              # Login, device-lock, session logic
├── utils.py              # Expiry parsing, fingerprinting, ASCII banner
├── requirements.txt
├── templates/
│   ├── index.html        # Original chat UI (English labels, Menu panel, chat logging added)
│   ├── login.html         # User login page
│   └── admin/
│       ├── login.html
│       └── dashboard.html
├── static/
├── uploads/
├── logs/
├── session/
└── database/
    └── database.db        # created automatically on first run
```

## Setup

```bash
pip install -r requirements.txt --break-system-packages   # if on Termux/Android
```

Set these before running (or edit config.py directly):

```bash
export OSINT_SECRET_KEY="a-long-random-string"
export OSINT_TG_TOKEN="123456:ABC-your-bot-token-from-BotFather"
export OSINT_TG_ADMIN_IDS="111111111"          # your Telegram numeric user ID
export OSINT_ADMIN_USER="admin"
export OSINT_ADMIN_PASS="a-strong-password"
```

## Running (single command — recommended)

```bash
python main.py
```

This one command starts **all three** at once, in one Termux session:
Main Website (8980), Admin Dashboard (8089), and the Telegram bot — no
need to open extra Termux tabs. Ctrl+C stops all three together.

## Running separately (advanced / multi-machine deployment)

If you want each piece on its own machine/container, run them
individually — each needs its own terminal, since each one blocks:

```bash
python app.py            # Main website  -> http://0.0.0.0:8980
python admin.py           # Admin panel   -> http://0.0.0.0:8089
python telegram_bot.py     # Account bot
```

**Important:** in the browser, never type `http://0.0.0.0:8980` or
`http://0.0.0.0:8089` — `0.0.0.0` is a bind address, not a real address,
and most browsers (including Chrome on Android) will refuse to connect
to it (`ERR_CONNECTION_REFUSED`). Use `http://127.0.0.1:8980` /
`http://127.0.0.1:8089` on the same device, or the LAN IP Flask prints
in the terminal (e.g. `http://192.168.0.105:8089`) from another device
on the same network.

## Creating an account (Telegram only — never from the website)

```
/create Repp76,123456            → permanent account
/create Repp76,123456,30h         → expires in 30 Hari (days)
/create Repp76,123456,6b          → expires in 6 Bulan (months)
/create Repp76,123456,12j         → expires in 12 Jam (hours)
/create Repp76,123456,2t          → expires in 2 Tahun (years)
```

Only Telegram user IDs listed in `OSINT_TG_ADMIN_IDS` can run this command.

## Device lock

The first successful login on an account permanently binds it to that
browser/device fingerprint (User-Agent + platform + screen + timezone +
canvas hash, hashed server-side). Any other device gets:

> "This account has already been registered on another device."

If a legitimate user gets a new phone, use **Reset Device** in the admin
dashboard to unbind it — the next login becomes the new registered device.

## About "stay logged in forever, even after clearing all browser data"

This is a hard limit, not a missing feature: a browser that has been
completely wiped (cookies + local storage + cache) has, by definition, no
token left that could prove who the visitor is — that applies to any
website built with HTML/JS/Python, not just this one.

What IS implemented, and covers every case in the spec that's actually
achievable:
- The session cookie is long-lived (400 days) and signed server-side, so
  restarting Python, restarting Termux, the phone rebooting, the
  Cloudflared URL changing, or the browser being closed and reopened all
  leave the user logged in — none of those touch the browser's own
  cookie storage.
- If the browser's site data is fully cleared, the session cookie is
  gone and the user is asked to log in again — but because the account
  stays permanently bound to that device's fingerprint, entering the
  same username/password on the same device logs back in immediately,
  with no new Telegram command and no admin involvement needed.

## Chat monitoring & moderation

Every user/assistant message is quietly mirrored to the database via
`/api/log` (fire-and-forget — a failed log call never breaks the chat).
The admin dashboard's **Chat** button on any account shows the full
history. The system never auto-cancels an account for anything said in
chat — cancellation is always a manual decision made from the dashboard.
