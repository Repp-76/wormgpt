"""
models.py — SQLAlchemy models shared by app.py, admin.py, and telegram_bot.py.

All three processes point at the SAME SQLite file (config.DATABASE_PATH),
so an account created by the Telegram bot is instantly visible to the
website and the dashboard with no restart required.
"""
from datetime import datetime, timedelta
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class User(db.Model):
    """A website account. Accounts are ONLY ever created by the Telegram bot."""
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)

    # Device lock: SHA-256 fingerprint of the first device that logs in.
    # Null until the first successful login.
    device_hash = db.Column(db.String(64), nullable=True)
    device_label = db.Column(db.String(255), nullable=True)  # human-readable UA summary

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=True)  # null == permanent
    is_permanent = db.Column(db.Boolean, default=False)

    is_cancelled = db.Column(db.Boolean, default=False)  # admin-cancelled
    last_seen = db.Column(db.DateTime, nullable=True)
    last_ip = db.Column(db.String(64), nullable=True)

    # Who created it (Telegram numeric id) for auditing.
    created_by_tg_id = db.Column(db.String(64), nullable=True)

    messages = db.relationship("ChatLog", backref="user", lazy="dynamic",
                                cascade="all, delete-orphan")

    def set_password(self, raw_password):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        return check_password_hash(self.password_hash, raw_password)

    @property
    def is_expired(self):
        if self.is_permanent or self.expires_at is None:
            return False
        return datetime.utcnow() > self.expires_at

    @property
    def is_active_account(self):
        """False if cancelled by admin OR naturally expired."""
        return not self.is_cancelled and not self.is_expired

    @property
    def is_online(self):
        if not self.last_seen:
            return False
        return (datetime.utcnow() - self.last_seen) < timedelta(minutes=3)

    def to_dict(self):
        return {
            "id": self.id,
            "username": self.username,
            "created_at": self.created_at.strftime("%Y-%m-%d %H:%M"),
            "expires_at": self.expires_at.strftime("%Y-%m-%d %H:%M") if self.expires_at else None,
            "is_permanent": self.is_permanent,
            "is_cancelled": self.is_cancelled,
            "is_expired": self.is_expired,
            "device_label": self.device_label,
            "is_online": self.is_online,
            "last_seen": self.last_seen.strftime("%Y-%m-%d %H:%M") if self.last_seen else None,
        }


class ChatLog(db.Model):
    """Copy of every message sent/received, for admin moderation review."""
    __tablename__ = "chat_logs"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    role = db.Column(db.String(16), nullable=False)  # "user" or "assistant"
    content = db.Column(db.Text, nullable=False)
    conversation_id = db.Column(db.String(64), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class MenuItem(db.Model):
    """A dynamic tool entry shown in the right-hand slide-out Menu panel."""
    __tablename__ = "menu_items"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)
    url = db.Column(db.String(512), nullable=False)
    description = db.Column(db.String(512), nullable=True)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self, censor_url=False):
        return {
            "id": self.id,
            "name": self.name,
            "url": _censor(self.url) if censor_url else self.url,
            "description": self.description or "",
        }


def _censor(url: str) -> str:
    """Partially hide a URL for the admin list view (per spec: 'URL (disensor)')."""
    if len(url) <= 14:
        return url[:4] + "•••"
    return url[:10] + "•••••" + url[-6:]
