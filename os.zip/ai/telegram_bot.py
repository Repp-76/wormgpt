"""
telegram_bot.py — the ONLY way accounts get created.

Run standalone:
    python telegram_bot.py

Command:
    /create <username>,<password>[,<expiry>]

Expiry suffix (Bahasa Melayu):
    h = Hari  (days)     30h  -> 30 Hari
    b = Bulan (months)   6b   -> 6 Bulan
    j = Jam   (hours)    12j  -> 12 Jam
    t = Tahun (years)    2t   -> 2 Tahun
    (omitted -> PERMANENT, no expiry)

Only Telegram user IDs listed in config.TELEGRAM_ADMIN_IDS may run /create.
"""
import logging

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

import config
from models import db, User
from utils import parse_expiry, InvalidDurationFormat, format_expiry_label, get_public_url
from flask import Flask

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("telegram_bot")

# A minimal Flask app instance purely to get an application context for
# SQLAlchemy, shared with app.py / admin.py via the same DATABASE_PATH.
_flask_app = Flask(__name__)
_flask_app.config["SQLALCHEMY_DATABASE_URI"] = config.SQLALCHEMY_DATABASE_URI
_flask_app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(_flask_app)

with _flask_app.app_context():
    db.create_all()


def _is_authorized(update: Update) -> bool:
    if not config.TELEGRAM_ADMIN_IDS:
        # Fail safe: if nobody is configured, refuse everything rather than
        # allow the whole world to create accounts.
        return False
    return update.effective_user.id in config.TELEGRAM_ADMIN_IDS


async def create_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_authorized(update):
        await update.message.reply_text("⛔ You are not authorized to use this bot.")
        logger.warning("Unauthorized /create attempt from tg_id=%s", update.effective_user.id)
        return

    raw = " ".join(context.args)
    if not raw or "," not in raw:
        await update.message.reply_text(
            "❌ Format salah.\n\n"
            "Guna: /create <username>,<password>[,<tempoh>]\n\n"
            "Contoh:\n"
            "/create Repp76,123456          (permanent)\n"
            "/create Repp76,123456,30h      (30 Hari)\n"
            "/create Repp76,123456,6b       (6 Bulan)\n"
            "/create Repp76,123456,12j      (12 Jam)\n"
            "/create Repp76,123456,2t       (2 Tahun)"
        )
        return

    parts = [p.strip() for p in raw.split(",")]
    if len(parts) not in (2, 3):
        await update.message.reply_text("❌ Format salah. Sila ikut: username,password[,tempoh]")
        return

    username = parts[0]
    password = parts[1]
    duration_str = parts[2] if len(parts) == 3 else None

    if not username or not password:
        await update.message.reply_text("❌ Username dan password tidak boleh kosong.")
        return

    try:
        expires_at, is_permanent = parse_expiry(duration_str)
    except InvalidDurationFormat as e:
        await update.message.reply_text(f"❌ {e}")
        return

    with _flask_app.app_context():
        if User.query.filter_by(username=username).first():
            await update.message.reply_text(f"❌ Username '{username}' sudah wujud.")
            return

        user = User(
            username=username,
            expires_at=expires_at,
            is_permanent=is_permanent,
            created_by_tg_id=str(update.effective_user.id),
        )
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

    label = format_expiry_label(expires_at, is_permanent)
    divider = "━" * 32
    await update.message.reply_text(
        f"{divider}\n"
        f"   ◆  A K A U N   S E D I A  ◆\n"
        f"{divider}\n\n"
        f"▸ Username : {username}\n"
        f"▸ Password : {password}\n"
        f"▸ Tempoh   : {label}\n\n"
        f"{divider}\n"
        f"▸ Portal   : {get_public_url()}\n"
        f"{divider}\n"
        f"        {config.BRAND_NAME} • {config.BRAND_AUTHOR}"
    )
    logger.info("Account created: %s (expiry=%s) by tg_id=%s", username, label, update.effective_user.id)


async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_authorized(update):
        await update.message.reply_text("⛔ Unauthorized.")
        return
    await update.message.reply_text(
        f"{config.BRAND_NAME} account bot.\n\n"
        "Use /create <username>,<password>[,<expiry>] to create an account.\n"
        "Expiry suffix: h=Hari, b=Bulan, j=Jam, t=Tahun. Omit for permanent."
    )


def build_application():
    """Build (but do not run) the Telegram Application. Shared by main.py
    (runs it in a background thread) and this file's own __main__ block
    (runs it standalone in the main thread)."""
    app = ApplicationBuilder().token(config.TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start_cmd))
    app.add_handler(CommandHandler("create", create_cmd))
    return app


def main():
    if config.TELEGRAM_BOT_TOKEN == "7663188091:AAFdU1_4_qT6vCXge0bydxSf8wHzbpZ8v74":
        logger.error("Set OSINT_TG_TOKEN (or edit config.py) before running the bot.")
        return
    if not config.TELEGRAM_ADMIN_IDS:
        logger.error("Set OSINT_TG_ADMIN_IDS (or edit config.py) before running the bot.")
        return

    application = build_application()
    logger.info("Telegram bot polling started.")
    application.run_polling()


if __name__ == "__main__":
    main()
